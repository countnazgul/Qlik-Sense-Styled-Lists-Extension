Qlik-Sense-Filter-Extension
===========================
